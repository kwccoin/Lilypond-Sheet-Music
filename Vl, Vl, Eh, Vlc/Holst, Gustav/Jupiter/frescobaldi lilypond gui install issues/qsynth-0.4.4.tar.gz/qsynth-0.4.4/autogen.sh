#!/bin/sh
#
make -f Makefile.git $*
